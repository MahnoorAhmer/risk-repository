#include <iostream>
#include <string>
using namespace std;

class Book {
private:
    string id;
    string name;
    double price;
    string author;
    string isbn;
public:
    Book() : id(""), name(""), price(0.0), author(""), isbn("") {}
    Book(const string& i, const string& n, double p, const string& a, const string& s)
        : id(i), name(n), price(p), author(a), isbn(s) {}
    string getId() const { return id; }
    string getName() const { return name; }
    double getPrice() const { return price; }
    string getAuthor() const { return author; }
    string getISBN() const { return isbn; }
    void setName(const string& n) { name = n; }
    void setPrice(double p) { price = p; }
    void setAuthor(const string& a) { author = a; }
    void setISBN(const string& s) { isbn = s; }
};

struct Node {
    Book book;
    Node* next;
    Node(const Book& b) : book(b), next(nullptr) {}
};

class BookList {
private:
    Node* tail;
public:
    BookList() : tail(nullptr) {}
    ~BookList() {
        if (!tail) return;
        Node* head = tail->next;
        Node* cur = head->next;
        while (cur != head) {
            Node* nxt = cur->next;
            delete cur;
            cur = nxt;
        }
        delete head;
    }

    void addBook(const string& id, const string& name, double price, const string& author, const string& isbn) {
        Book b(id, name, price, author, isbn);
        Node* n = new Node(b);
        if (!tail) {
            tail = n;
            tail->next = tail;
        } else {
            n->next = tail->next;
            tail->next = n;
            tail = n;
        }
    }

    void removeBook(const string& id) {
        if (!tail) { cout << "remove failed\n"; return; }
        Node* cur = tail->next;
        Node* prev = tail;
        do {
            if (cur->book.getId() == id) {
                if (cur == prev) { delete cur; tail = nullptr; }
                else {
                    prev->next = cur->next;
                    if (cur == tail) tail = prev;
                    delete cur;
                }
                cout << "deleted successfully\n";
                return;
            }
            prev = cur;
            cur = cur->next;
        } while (cur != tail->next);
        cout << "remove failed\n";
    }

    void updateBook(const string& id, const string& name, double price, const string& author, const string& isbn) {
        if (!tail) { cout << "update failed\n"; return; }
        Node* cur = tail->next;
        do {
            if (cur->book.getId() == id) {
                cur->book.setName(name);
                cur->book.setPrice(price);
                cur->book.setAuthor(author);
                cur->book.setISBN(isbn);
                cout << "updated successfully\n";
                return;
            }
            cur = cur->next;
        } while (cur != tail->next);
        cout << "update failed\n";
    }

    void printBooks() const {
        if (!tail) { cout << "No books\n"; return; }
        Node* cur = tail->next;
        int i = 1;
        do {
            const Book& b = cur->book;
            cout << i++ << ". " << b.getId() << " | " << b.getName() << " | " << b.getPrice() << " | " << b.getAuthor() << " | " << b.getISBN() << '\n';
            cur = cur->next;
        } while (cur != tail->next);
    }

    void printBook(const string& id) const {
        if (!tail) { cout << "print failed\n"; return; }
        Node* cur = tail->next;
        do {
            if (cur->book.getId() == id) {
                const Book& b = cur->book;
                cout << "ID: " << b.getId() << '\n';
                cout << "Name: " << b.getName() << '\n';
                cout << "Price: " << b.getPrice() << '\n';
                cout << "Author: " << b.getAuthor() << '\n';
                cout << "ISBN: " << b.getISBN() << '\n';
                return;
            }
            cur = cur->next;
        } while (cur != tail->next);
        cout << "print failed\n";
    }
};

int main() {
    BookList bl;
    bl.addBook("B01","C++ Basics",2500.0,"A Author","ISBN01");
    bl.addBook("B02","DSA Intro",3000.0,"B Author","ISBN02");
    bl.addBook("B03","OOP Guide",2800.0,"C Author","ISBN03");
    bl.addBook("B04","DB Systems",2600.0,"D Author","ISBN04");
    bl.addBook("B05","Networks",2700.0,"E Author","ISBN05");

    bl.printBooks();
    bl.removeBook("B03");
    bl.printBooks();
    bl.updateBook("B02","Data Structures & Algorithms",3200.0,"B Author","ISBN02-RE");
    bl.printBook("B02");
    bl.printBook("B99");
    return 0;
}

