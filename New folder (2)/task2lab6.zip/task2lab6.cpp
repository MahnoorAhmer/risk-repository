#include <iostream>   
#include <string>
using namespace std;

struct Node {                  //task 2 lab 6
                           //mahnoor ahmer 63430
    string name;
    Node* next;
    Node(const string& s) : name(s), next(nullptr) {}
};

class EmployeeList {
private:
    Node* tail;
public:
    EmployeeList() : tail(nullptr) {}

    bool exists(const string& name) const {
        if (!tail) return false;
        Node* cur = tail->next;
        do {
            if (cur->name == name) return true;
            cur = cur->next;
        } while (cur != tail->next);
        return false;
    }

    void addEmployee(const string& name) {
        if (exists(name)) {
            cout << "add failed: name already exists\n";
            return;
        }
        Node* node = new Node(name);
        if (!tail) {
            tail = node;
            tail->next = tail;
        } else {
            node->next = tail->next;
            tail->next = node;
            tail = node;
        }
        cout << "added successfully\n";
    }

    void deleteEmployee(const string& name) {
        if (!tail) {
            cout << "delete failed: list empty\n";
            return;
        }
        Node* curr = tail->next;
        Node* prev = tail;
        do {
            if (curr->name == name) {
                if (curr == prev) {
                    delete curr;
                    tail = nullptr;
                } else {
                    prev->next = curr->next;
                    if (curr == tail) tail = prev;
                    delete curr;
                }
                cout << "deleted successfully\n";
                return;
            }
            prev = curr;
            curr = curr->next;
        } while (curr != tail->next);
        cout << "delete failed: name not found\n";
    }

    void updateEmployee(const string& oldName, const string& newName) {
        if (!tail) {
            cout << "update failed: list empty\n";
            return;
        }
        if (exists(newName)) {
            cout << "update failed: new name already exists\n";
            return;
        }
        Node* cur = tail->next;
        do {
            if (cur->name == oldName) {
                cur->name = newName;
                cout << "updated successfully\n";
                return;
            }
            cur = cur->next;
        } while (cur != tail->next);
        cout << "update failed: old name not found\n";
    }

    void findEmployee(const string& name) const {
        if (exists(name)) cout << "found successfully\n";
        else cout << "not found\n";
    }

    void printAll() const {
        if (!tail) {
            cout << "No employees.\n";
            return;
        }
        Node* cur = tail->next;
        cout << "Employees list:\n";
        do {
            cout << "- " << cur->name << "\n";
            cur = cur->next;
        } while (cur != tail->next);
    }
};

int main() {
    EmployeeList el;
    el.addEmployee("Ali");
    el.addEmployee("Sara");
    el.addEmployee("Bilal");
    el.addEmployee("Zara");
    el.addEmployee("Usman");
    el.printAll();
    el.findEmployee("Sara");
    el.findEmployee("Noor");
    el.updateEmployee("Bilal", "BilalK");
    el.updateEmployee("Noone", "X");
    el.addEmployee("Sara");
    el.deleteEmployee("Zara");
    el.deleteEmployee("NotExist");
    el.printAll();
    return 0;
}

